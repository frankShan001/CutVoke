"""CutVoke domain modules."""
