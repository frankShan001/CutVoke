"""CutVoke domain modules."""
