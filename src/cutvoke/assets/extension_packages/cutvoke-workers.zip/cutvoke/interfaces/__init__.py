"""CutVoke interfaces modules."""
