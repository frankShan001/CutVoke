"""CutVoke interfaces modules."""
