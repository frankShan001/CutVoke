"""CutVoke storage modules."""
