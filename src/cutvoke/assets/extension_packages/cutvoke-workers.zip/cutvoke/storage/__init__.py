"""CutVoke storage modules."""
